IDENTIFYING INFORMATION
Full Name: Vincent jodjana
Student ID: 2339106
Chapman Email: jodjana@chapman.edu
Course Number and Section: 236-01
Assignment or Exercise Number: Final Project

A LIST OF ALL THE SOURCE FIELD SUBMITTED FOR THIS Assignment
Capture.png
PaperPlane.jpg
Pencil.jpg

A DESCRIPTION OF ALL REFERENCES USED TO COMPLETE THE ASSIGNMENT, INCLUDING PEERS (IF APPLICABLE)
a. Derek Prate
b. Dan Haub
c. https://www.youtube.com/watch?v=A-GkNM8M5p8
d. https://www.youtube.com/watch?v=ofZtyysHp1s
e. https://www.youtube.com/watch?v=zc8ac_qUXQY
f. https://unity3d.com/learn/tutorials/topics/user-interface-ui/creating-main-menu
g. https://www.youtube.com/watch?v=3HSMTN3pQI0
h. https://www.youtube.com/watch?v=TAGZxRMloyU

INSTRUCTIONS FOR RUNNING THE Assignment
1. unzip folder
2. Open project folder using Unity
3. Open Unity Application for FlimsyPlane
4. Play Game
5. When Finished, may restart or return to main menu
6. If need instruction, click help button
7. To end, press quit on main menu